from flask import Flask, request, render_template, jsonify, make_response
from dotenv import load_dotenv
import os
import requests
import json
from datetime import datetime, timedelta

# .env 파일에서 환경 변수를 로드
load_dotenv()

app = Flask(__name__)
api_token = os.getenv('LOA_API_TOKEN')

headers = {
    'accept': 'application/json',
    'authorization': f'bearer {api_token}',
    'Content-Type': 'application/json',
}

def get_item_data(item_name, category_code=50000, page_no=0, exact_match=False):
    url = "https://developer-lostark.game.onstove.com/markets/items"
    json_data = {
        "Sort": "GRADE",
        "CategoryCode": category_code,
        "CharacterClass": "",
        "ItemTier": None,
        "ItemGrade": "",
        "ItemName": item_name,
        "PageNo": page_no,
        "SortCondition": "ASC"
    }
    response = requests.post(url, headers=headers, json=json_data)
    if response.status_code == 200:
        data = response.json()
        # 정확히 일치하는 이름만 필터링 (즐겨찾기인 경우에만)
        if exact_match:
            data['Items'] = [item for item in data['Items'] if item['Name'] == item_name]
        print("Data fetched successfully")  # 디버깅 메시지 추가
        return data
    else:
        print(f"API 호출 실패: {response.status_code}")
        return None
    
def get_events():
    url = "https://developer-lostark.game.onstove.com/news/events"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()  # 이벤트 목록을 JSON으로 반환
    else:
        print(f"API 호출 실패: {response.status_code}")
        return []


# 캐릭터 프로필 조회 함수
def get_character_profile(character_name):
    url = f"https://developer-lostark.game.onstove.com/armories/characters/{character_name}/profiles"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"API 호출 실패: {response.status_code}")
        return []
    
# 캐릭터 형제 조회 함수
def get_siblings(character_name):
    url = f"https://developer-lostark.game.onstove.com/characters/{character_name}/siblings"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        print("Failed to fetch siblings data:", response.status_code)
        return []

# 공지사항 API 호출 함수
def get_notices(search_text="", notice_type=""):
    url = "https://developer-lostark.game.onstove.com/news/notices"
    params = {
        'searchText': search_text,
        'type': notice_type
    }
    response = requests.get(url, headers=headers, params=params)
    if response.status_code == 200:
        data = response.json()
        # 최근 1주일 공지만 필터링
        one_week_ago = datetime.now() - timedelta(days=7)
        recent_notices = []
        for notice in data:
            if 'Date' in notice:
                try:
                    # ISO 형식 변환 시도
                    notice_date = datetime.fromisoformat(notice['Date'].replace("Z", "+00:00"))
                    if notice_date >= one_week_ago:
                        recent_notices.append(notice)
                except ValueError:
                    # 형식 오류가 발생하는 경우 해당 데이터를 건너뜁니다.
                    print(f"Invalid date format in notice: {notice['Date']}")
        return recent_notices
    else:
        print("Failed to fetch notices:", response.status_code)
        return []

    
# 기존 아이템 검색 페이지 라우터
@app.route('/item', methods=['GET', 'POST'])
def item():
    print("Inside item route")  # 디버깅 메시지 추가
    favorite_items = request.cookies.get('favorites')
    favorite_items = json.loads(favorite_items) if favorite_items else []

    item_data_list = []

    # POST 요청이 있을 경우 아이템 검색 (부분 일치 허용)
    if request.method == 'POST':
        item_name = request.form['item_name']
        print(f"Searching for item: {item_name}")  # 디버깅 메시지 추가
        item_data = get_item_data(item_name, exact_match=False)
        if item_data:
            item_data_list = item_data['Items']
    
    # 즐겨찾기된 아이템도 가져오기 (정확히 일치하는 항목만)
    for favorite_item in favorite_items:
        favorite_data = get_item_data(favorite_item, exact_match=True)
        if favorite_data and 'Items' in favorite_data:
            item_data_list.extend(favorite_data['Items'])

    return render_template('item.html', item_data=item_data_list, favorites=favorite_items)



# 즐겨찾기 추가/제거 라우터
@app.route('/toggle_favorite', methods=['POST'])
def toggle_favorite():
    item_name = request.json['item_name']
    favorites = request.cookies.get('favorites')
    favorites = json.loads(favorites) if favorites else []

    # 디버깅 메시지
    print(f"Current favorites before toggle: {favorites}")

    if item_name in favorites:
        favorites.remove(item_name)
        print(f"Removed {item_name} from favorites")
    else:
        favorites.append(item_name)
        print(f"Added {item_name} to favorites")

    response = make_response(jsonify({"status": "success"}))
    response.set_cookie('favorites', json.dumps(favorites))
    return response

#기본 시작 화면
@app.route('/')
def home():
    notices = get_notices()
    return render_template('home.html', notices=notices)


@app.route('/char', methods=['GET', 'POST'])
def char():
    profile_data = None
    siblings_data = None
    if request.method == 'POST':
        character_name = request.form['character_name']
        
        # 프로필 정보 가져오기
        profile_url = f"https://developer-lostark.game.onstove.com/armories/characters/{character_name}/profiles"
        profile_response = requests.get(profile_url, headers=headers)
        
        if profile_response.status_code == 200:
            profile_data = profile_response.json()
            profile_server = profile_data.get('ServerName')
        
        # 형제 정보 가져오기
        siblings_data = get_siblings(character_name)
        
        # 형제 캐릭터 데이터 정렬
        if siblings_data:
            siblings_data = sorted(
                siblings_data,
                key=lambda x: (
                    x['ServerName'] != profile_server,  # 서버가 같은 캐릭터가 먼저 오도록
                    -x['CharacterLevel']  # 레벨이 높은 캐릭터가 먼저 오도록
                )
            )
    
    return render_template('char.html', profile_data=profile_data, siblings_data=siblings_data)




# 이벤트 페이지 라우트
@app.route('/events')
def events():
    events_data = get_events()  # 이벤트 데이터 가져오기
    return render_template('events.html', events_data=events_data)

if __name__ == "__main__":
    app.run(debug=True)
